==========================
atomisator.indexer package
==========================

This package provides an indexing plugin for Atomisator.
It uses Xapian, through afpy.xap.

The idea is that you can use Atomisator to build
an indexing database out of several data sources.

From there it can be used on various purposes.

For more information, go to http://atomisator.ziade.org

