Explain here what the package does.

    >>> 1 + 1
    2
