========
Doctests
========

This folder contains doctests for pbp.skels package.

