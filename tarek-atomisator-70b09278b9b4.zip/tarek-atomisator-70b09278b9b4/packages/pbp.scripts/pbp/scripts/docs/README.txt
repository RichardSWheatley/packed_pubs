========
Doctests
========

This folder contains doctests.

    >>> 1 + 1
    2

