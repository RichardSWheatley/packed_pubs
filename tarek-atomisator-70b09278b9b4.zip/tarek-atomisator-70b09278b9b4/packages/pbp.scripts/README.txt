===================
pbp.scripts package
===================

This package is part of the `Expert Python Programming` book  written by
Tarek Ziadé.


For more information, go to http://atomisator.ziade.org

This small package provides some scripts used througout the book.

