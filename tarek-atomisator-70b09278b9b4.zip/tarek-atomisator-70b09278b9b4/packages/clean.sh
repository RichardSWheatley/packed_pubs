cd atomisator.filters
rm -rf *egg-info build dist
cd ..

cd atomisator.db
rm -rf *egg-info build dist
cd ..

cd atomisator.feed
rm -rf *egg-info build dist    
cd ..

cd atomisator.main
rm -rf *egg-info build dist    
cd ..

cd atomisator.parser
rm -rf *egg-info build dist    
cd ..

cd pbp.buildbotenv
rm -rf *egg-info build dist    
cd ..

cd pbp.recipe.noserunner
rm -rf *egg-info build dist    
cd ..

cd pbp.recipe.trac
rm -rf *egg-info build dist    
cd ..

cd pbp.scripts
rm -rf *egg-info build dist    
cd ..

cd pbp.skels
rm -rf *egg-info build dist    
cd ..
