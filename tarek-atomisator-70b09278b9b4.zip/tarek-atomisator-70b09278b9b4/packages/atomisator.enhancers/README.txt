==========================
atomisator.filters package
==========================

This package is part of the `Expert Python Programming` book  written by 
Tarek Ziadé.


For more information, go to http://atomisator.ziade.org

