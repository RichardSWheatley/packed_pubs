cd atomisator.enhancers
echo atomisator.enhancers
python setup.py --version
cd ..

cd atomisator.filters
echo atomisator.filters
python setup.py --version
cd ..

cd atomisator.db
echo atomisator.db
python setup.py --version
cd ..

cd atomisator.feed
echo atomisator.feed
python setup.py --version
cd ..

cd atomisator.main
echo atomisator.main
python setup.py --version
cd ..

cd atomisator.parser
echo atomisator.parser
python setup.py --version
cd ..

cd pbp.buildbotenv
echo pbp.buildbotenv
python setup.py --version
cd ..

cd pbp.recipe.noserunner
echo pbp.recipe.noserunner
python setup.py --version
cd ..

cd pbp.recipe.trac
echo pbp.recipe.trac
python setup.py --version
cd ..

cd pbp.scripts
echo pbp.scripts
python setup.py --version
cd ..

cd pbp.skels
echo pbp.skels
python setup.py --version
cd ..

