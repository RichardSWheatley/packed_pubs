#define GSL_SUCCESS = 0
#define GSL_FAILURE = -1
#define GSL_ERROR(x1,x2,x3) do {} while(0)
