# -*- encoding: utf-8 -*-                                                      
# (C) Copyright 2008 Tarek Ziadé <tarek@ziade.org>                             
# 
